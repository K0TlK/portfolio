let arr = [
 //Уровень в меню, ссылка, якорь
 [0,'index.html','Скачать'],
 [0,'docs.html','Документация'],
 [1,'docs.html#constructor','Конструктор'],
 [1,'docs.html#animate','animate (ms)'],
 [1,'docs.html#animateto','animateTo (ms, pos1, pos2)'],
 [1,'docs.html#getcolors','getColors ()'],
 [1,'docs.html#getend','getEnd ()'],
 [1,'docs.html#gethtml','getHTML ()'],
 [1,'docs.html#getlimits','getLimits ()'],
 [1,'docs.html#getstart','getStart ()'],
 [1,'docs.html#getstate','getState ()'],
 [1,'docs.html#getwidth','getWidth ()'],
 [1,'docs.html#reset','reset ()'],
 [1,'docs.html#setcolors','setColors (col, bCol, tCol)'],
 [1,'docs.html#setend','setEnd (end)'],
 [1,'docs.html#setlimits','setLimits (start, end)'],
 [1,'docs.html#setstart','setStart (start)'],
 [1,'docs.html#setstate','setState (state)'],
 [1,'docs.html#setwidth','setWidth (width)'],
 [0,'examples.html','Примеры'],
 [1,'examples.html#animation','Анимация'],
 [1,'examples.html#manually','Управление вручную'],
 [1,'examples.html#colors','Выбор цветов']
];

function printHeader (id, hdr) { //Построитель заголовков окна и страницы
 let elem = document.getElementById(id);
 if (!elem) {
  console.error ('printHeader: Item id not found: '+id);
  return;
 }
 let str = hdr, len = arr.length;
 for (let i = 0; i < len; i++) {
  let url = window.location.pathname;
  let filename = url.substring(url.lastIndexOf('/')+1);
  if (arr[i][1].startsWith(filename)) {
   str += ': ' + arr[i][2];
   break;
  }
 }
 elem.innerHTML = str;
}

function printMenu (id) { //Построитель меню
 let elem = document.getElementById(id);
 if (!elem) {
  console.error ('printMenu: Item id not found: '+id);
  return;
 }
 let str = '', len = arr.length;
 for (let i = 0; i < len; i++) {
  for (let level = 0; level < arr[i][0]; level++) str += '&nbsp;';
  str += 
   (arr[i][0]?'&bull;':'') + 
   '<a href="'+arr[i][1]+'">'+arr[i][2]+'</a>' + (i < len - 1 ? "<br>\n" : '');
 }
 elem.innerHTML = str;
}

function makeList (id,a,b,dx,x0,val0,dval,fname) { //Построитель выпадающих списков
 //id элемента, левая граница, правая граница, шаг, выбранное значение,
 //первая value в списке, шаг по value в списке, функцифя для обработки onchange
 let elem = document.getElementById(id);
 if (!elem) {
  console.error ('makeList: Item id not found: '+id);
  return;
 }
 let val = val0;
 let lst = '<select size="1" id="'+id+'_list" onchange="'+fname+'();">';
  //Добавляем суффикс _list к имени исходного элемента, в который пишем список
 for (let x = a; x <= b; x += dx) { //Формируем опции списка
  lst += '<option value="'+val+'"'+ (x == x0 ? ' selected' : '') + '>'+x+'</option>' + "\n";
  val += dval;
 }
 elem.innerHTML = lst + '</select>';
}
