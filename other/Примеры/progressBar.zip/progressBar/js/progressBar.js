class progressBar {
 constructor (id) {
  this.id = id;
  this.elem = document.getElementById (id);
  if (!this.elem) {
   console.error ('progressBar: Item with id='+id+' not found');
   return null;
  }
  this.animation = 0;
  this.start = 0;
  this.state = 0;
  this.end = 100;
  this.color = '#eee'; //Основной фон
  this.borderColor = '#0b3'; //Рамка и закрашенное
  this.textColor = '#000'; //Текст
  this.width = 100;
  let child = this.createWrapper ();
  let bar = this.createBar ();
  let percent = this.createPercent ();
  child.appendChild (percent);
  child.appendChild (bar);
  this.elem.appendChild (child);
 }
 animate (ms) {
  this.animateTo (ms, this.start, this.end);
 }
 animateTo (ms, pos1, pos2) {
  if (!this.elem) {
   console.error ('animateTo: Item with id='+this.id+' not found');
   return;
  }
  ms = parseInt (ms);
  if (isNaN(ms) || ms < 1) {
   console.error ('animateTo: ms is not a positive number'); 
   return;
  }
  let a = parseInt (pos1), b = parseInt (pos2);
  if (isNaN(a) || isNaN(b)) {
   console.error ('animateTo: pos1 or pos2 is not a number'); 
   return;
  }
  if (a > b) { let t = a; a = b; b = t; }
  if (a < this.start) a = this.start;
  if (b > this.end) b = this.end;
  let dt = new Date();
  this.startTime = dt.getTime();
  this.endTime = this.startTime + ms;
//console.log ('Расчётное время='+(this.endTime-this.startTime)/1000);
  this.setState (a);
  this.timeInterval = Math.max(Math.round (ms / (b - a)), 1);
  this.a = a;
  this.b = b;
  this.doTimer();
 }
 getColors () {
  return [this.color, this.borderColor, this.textColor];
 }
 getEnd () {
  return this.end;
 }
 getHTML () {
  let elem = document.getElementById(this.id + '_child');
  if (!elem) {
   console.error ('getHTML: Wrapper item not found for id='+this.id);
   return;
  }
  return elem.outerHTML;
 }
 getLimits () {
  return [this.start, this.end];
 }
 getStart () {
  return this.start;
 }
 getState () {
  return this.state;
 }
 getWidth () {
  return this.width;
 }
 reset () {
  this.state = 0;
  this.start = 0;
  this.end = 100;
  this.width = 100;
  this.color = '#eee';
  this.borderColor = '#0b3';
  this.textColor = '#000';
  this.update();
 }
 setColors (col = '#eee', bCol = '#0b3', tCol = '#000') {
  let cnt = 0;
  if (this.isColorValid(col)) { cnt++; this.color = col; }
  if (this.isColorValid(bCol)) { cnt++; this.borderColor = bCol; }
  if (this.isColorValid(tCol)) { cnt++; this.textColor = tCol; }
  if (cnt) this.update();
 }
 setEnd (end = 100) {
  let val = parseInt (end);
  if (isNaN(val)) {
   console.error ('setEnd: end is not a number'); 
   return;
  }
  let oldStart = this.start, oldEnd = this.end;
  if (val < this.start) { 
   this.end = this.start; this.start = val; 
  }
  else this.end = val;
  this.state = this.recalc (oldStart,this.state,oldEnd,this.start,this.end);
  this.update();
 }
 setLimits (start = 0, end = 100) {
  let a = parseInt (start), b = parseInt (end);
  if (isNaN(a) || isNaN(b)) {
   console.error ('setLimits: start or end is not a number'); 
   return;
  }
  if (a > b) { let t = a; a = b; b = t; }
  this.setStart (a);
  this.setEnd (b);
 }
 setStart (start = 0) {
  let val = parseInt (start);
  if (isNaN(val)) {
   console.error ('setStart: start is not a number'); 
   return;
  }
  let oldStart = this.start, oldEnd = this.end;
  if (val > this.end) { 
   this.start = this.end; this.end = val; 
  }
  else this.start = val;
  this.state = this.recalc (oldStart,this.state,oldEnd,this.start,this.end);
  this.update();
 }
 setState (state = 0) {
  let val = parseInt (state);
  if (isNaN(val)) {
   console.error ('setState: state is not a number'); 
   return;
  }
  if (val < this.start) val = this.start;
  if (val > this.end) val = this.end;
  this.state = val;
  this.update();
 }
 setWidth (width = 100) {
  let val = parseInt (width);
  if (isNaN(val) || val < 51) {
   console.error ('setWidth: setWidth is not a positive number, larger 50'); 
   return;
  }
  this.width = val;
  this.update();
 }
 //Далее - служебные методы
 update () {
  let elem = document.getElementById (this.id + '_child');
  if (!elem) {
   console.error ('update: Wrapper item not found for id=' + this.id);
   return;
  }
  let child = this.createWrapper ();
  let bar = this.createBar ();
  let percent = this.createPercent ();
  child.appendChild (percent);
  child.appendChild (bar);
  elem.parentNode.replaceChild (child, elem);
 }
 doTimer () { 
  let dt = new Date();
  let currentTime = dt.getTime();
  if (currentTime < this.endTime) {
   let st = this.recalc (this.startTime,currentTime,this.endTime,this.a,this.b);
   if (st < this.a) st = this.a;
   else if (st > this.b) st = this.b;
   this.setState (st);
   let that = this; //Без такого "клонирования" this не работает setTimeout из класса
   this.timerId = setTimeout(function () { that.doTimer (); }, that.timeInterval);
  }
  else {
   this.setState (this.b);
   clearInterval(this.timerId);
//let rd = new Date(); console.log ('Реальное время='+(rd.getTime()-this.startTime)/1000);  
  }
 }
 createWrapper () {
  let child = document.createElement('span');
  child.setAttribute('id', this.id + '_child');
  child.style.display = 'inline-block';
  child.style.position = 'relative';
  child.style.verticalAlign = 'middle';
  child.style.width = this.width+'px';
  child.style.height = '1.1em';     //Равные значения, сработает для
  child.style.lineHeight = '1.1em'; //однострочных элементов
  child.style.backgroundColor = this.color;
  child.style.borderColor = this.borderColor;
  child.style.borderWidth = '1px';
  child.style.borderRadius = '3px';
  child.style.borderStyle = 'solid';
  child.style.padding = '0';
  return child;
 }
 createBar () {
  let bar = document.createElement('span');
  bar.setAttribute('id', this.id + '_bar');
  bar.style.display = 'inline-block';
  bar.style.height = '100%';
  bar.style.lineHeight = '100%';
  let m = Math.round(0 + (this.state - this.start) * 100/(this.end - this.start));
  bar.style.width = m + '%';
  bar.style.backgroundColor = this.borderColor;
  return bar;
 }
 createPercent () {
  let percent = document.createElement('span');
  percent.setAttribute('id', this.id + '_percent');
  percent.style.position = 'absolute';
  percent.style.fontSize = '60%'; 
  percent.style.right = '1px';
  percent.style.top = '1px';
  percent.style.color = this.textColor;
  let msg = '';
  if (this.state == this.start) msg = '0';
  else if (this.state == this.end) msg = '100%';
  else msg = '[' + this.start + '..' + this.state + '..' + this.end + ']';
  percent.innerHTML = msg;
  return percent;
 }
 getColorCSS (c) {
  let elem = document.createElement("span");
  elem.style.color = c;
  return elem.style.color.split(/\s+/).join('').toLowerCase();
 }
 isColorValid (c) {
  let s = this.getColorCSS(c);
  return (s) ? true : false;
 }
 recalc (a,x,b,c,d) { //Пересчет x из [a,b] в y из [c,d]
//console.log(a+','+x+','+b+','+c+','+d);
  if (a == b) return c;
  return Math.round(c + (x - a) * (d - c) / (b - a));
 }
} //class progressBar